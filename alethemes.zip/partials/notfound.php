<section class="not-found">
	<p><?php _e('No results were found for the requested page.', 'aletheme');?></p>
</section>